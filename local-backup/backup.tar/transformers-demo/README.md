# Transformers.js 로컬 분류 데모

실행: `~/transformers-demo/start.sh`

폰 브라우저에서 http://127.0.0.1:8765 를 열고 문장과 쉼표로 구분한 선택지(2~10개)를 입력합니다.
서버가 이미 켜져 있으면 페이지를 바로 열면 됩니다. 서버 종료는 Ctrl+C입니다.

- Transformers.js 3.8.1, ONNX Runtime Web, CPU/WASM 단일 스레드
- 모델: onnx-community/mDeBERTa-v3-base-xnli-multilingual-nli-2mil7-ONNX (q8)
- 라이브러리, WASM, 모델을 모두 로컬에 저장하며 외부 모델 로딩을 비활성화했습니다.
- 실제 추론은 브라우저에서 진행합니다. Python은 정적 파일만 제공합니다.
- 상대 분류 점수는 정답 확률이 아닙니다. 한국어 기본 예제 3개와 사용자가 보고한 영어 환불 오분류를 검증합니다. 확장한 한국어 예제 12개 중 8개만 맞혔으므로 일반 판단 자동화에 충분한 품질이라고 볼 수 없습니다.
- 검증 결과: results.json

검증 재실행: 설치된 Chromium을 격리 프로필로 시작한 후 `node check.mjs`.

```sh
env LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib chromium-browser --headless --no-sandbox --disable-dev-shm-usage --user-data-dir="$HOME/transformers-demo/.chromium-test" --remote-debugging-port=9223 about:blank
```

로컬 서버가 켜진 상태에서 다른 Termux 세션에서:

```sh
cd ~/transformers-demo
node check.mjs
```

검증은 외부 모델/CDN 주소를 차단하고 한국어 환불·배송·계정 분류, 점수 합계, UI 완료, 로컬 요청만 발생했는지를 확인합니다.

공식 문서: https://huggingface.co/docs/transformers.js/
모델: https://huggingface.co/onnx-community/mDeBERTa-v3-base-xnli-multilingual-nli-2mil7-ONNX

입력에 한글이 있으면 한국어 가설 문장, 그렇지 않으면 영어 가설 문장을 사용합니다. 모델을 키워 사용자 영어 예제는 수정했지만 한국어 확장 검증은 여전히 취약합니다. 비교 결과는 experiment-results.json, english-results.json, upgrade-results.json에 있습니다.

## 로컬 HTTP API

현재 API 주소는 `http://127.0.0.1:8766`입니다. Termux 세션에서 `~/transformers-demo/api-start.sh`를 실행하고 Ready 메시지를 기다립니다. 종료는 Ctrl+C입니다. 이미 실행 중이면 새로 시작할 필요가 없습니다.

```sh
curl http://127.0.0.1:8766/classify \
  -H 'Content-Type: application/json' \
  -d '{"text":"the product is not working. please refund it.","labels":["refund request","delivery ask","account problems"]}'
```

응답: `sequence`, 점수 순서로 정렬된 `labels`, 상대 분류 점수 `scores`, `load_ms`, `inference_ms`.

- 상태 확인: `GET /health` → `{"ready":true,"busy":false}`
- 문장: 1~2000자. 선택지: 중복 없는 2~10개, 각 1~200자. 요청 본문 최대 16KB.
- 잘못된 입력: 400, 본문 초과: 413, Content-Type 오류: 415, 모델 로딩 중: 503, 다른 요청 처리 중: 429.
- 한 번에 요청 하나만 처리합니다. 429이면 잠시 후 재시도합니다.
- 이 API는 같은 기기의 루프백 주소에서만 받습니다.
- Node.js HTTP 서버가 별도 headless Chromium의 기존 Transformers.js 분류 함수를 호출합니다. 터미널에서 호출할 때 사용자가 브라우저 창을 띄울 필요는 없습니다.
- API가 정적 파일 서버(8767)와 전용 Chromium 프로필/디버깅 포트(9224)를 관리합니다. 추론 시 외부 모델/CDN 주소를 차단합니다.
- 검증: `node ~/transformers-demo/check-api.mjs`. 실제 결과는 `api-results.json`.

이번 세션에서 백그라운드로 시작한 API의 PID는 `api.pid`에 저장했고, 로그는 `api.log`입니다. 종료하려면 `kill "$(cat ~/transformers-demo/api.pid)"`를 사용합니다. 이후 직접 실행한 API는 Ctrl+C로 종료합니다.
