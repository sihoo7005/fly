import { pipeline, env } from './vendor/transformers.min.js';
env.allowRemoteModels = false;
env.allowLocalModels = true;
env.localModelPath = './models/';
env.backends.onnx.wasm.wasmPaths = new URL('./vendor/', location.href).href;
env.backends.onnx.wasm.numThreads = 1;
const status = document.querySelector('#status');
const result = document.querySelector('#result');
const button = document.querySelector('#run');
let classifier;
async function classify(text, labels) {
  const start = performance.now();
  if (!classifier) {
    status.textContent = '모델 로딩 중…';
    classifier = await pipeline('zero-shot-classification', 'mDeBERTa-v3-base-xnli-multilingual-nli-2mil7', { device: 'wasm', dtype: 'q8' });
  }
  const loaded = performance.now();
  const hypothesis_template = /[가-힣]/u.test(text) ? '이 문장은 {}에 관한 내용입니다.' : 'This text is about {}.';
  const output = await classifier(text, labels, { hypothesis_template });
  return { ...output, load_ms: Math.round(loaded-start), inference_ms: Math.round(performance.now()-loaded) };
}
window.classify = classify;
button.onclick = async () => {
  const text = document.querySelector('#text').value.trim();
  const labels = document.querySelector('#labels').value.split(',').map(x=>x.trim()).filter(Boolean);
  if (!text || labels.length<2 || labels.length>10) { status.textContent='문장과 2~10개의 선택지를 입력해 주세요.'; return; }
  button.disabled=true; result.textContent='';
  try {
    status.textContent='분류 중…';
    const output = await classify(text, labels);
    result.textContent=output.labels.map((label,i)=>`${label}: ${(output.scores[i]*100).toFixed(1)}%`).join('\n');
    status.textContent=`완료 · 모델 로딩 ${output.load_ms}ms · 추론 ${output.inference_ms}ms · CPU/WASM`;
  } catch(error) { status.textContent='실행 실패'; result.textContent=String(error); }
  finally { button.disabled=false; }
};
