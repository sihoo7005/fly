(async()=>{
 const {pipeline,env}=await import('./vendor/transformers.min.js');
 env.allowRemoteModels=false;env.allowLocalModels=true;env.localModelPath='./models/';
 env.backends.onnx.wasm.wasmPaths=new URL('./vendor/',location.href).href;env.backends.onnx.wasm.numThreads=1;
 const model=await pipeline('zero-shot-classification','multilingual-MiniLMv2-L6-mnli-xnli',{dtype:'q8',device:'wasm'});
 const samples=[
 ['상품이 고장 났어요. 환불해 주세요.',0],['구매를 취소하고 돈을 돌려받고 싶습니다.',0],['배송은 잘 받았고 계정도 정상입니다. 결제 취소만 해 주세요.',0],['환불 접수했는데 아직 돈이 안 들어왔어요.',0],
 ['택배가 아직 도착하지 않았어요. 언제 배송되나요?',1],['주문한 물건이 지금 어디쯤 있는지 알고 싶어요.',1],['환불하려는 게 아니라 배송 날짜가 궁금합니다.',1],['로그인은 되는데 주문한 택배의 운송장 번호가 안 보여요.',1],
 ['비밀번호를 잊어버려서 로그인이 안 됩니다.',2],['회원 가입하려는데 인증 메일이 안 와요.',2],['배송이나 환불 문제가 아니라 계정이 잠겨서 접속할 수 없습니다.',2],['비밀번호 재설정 링크를 보내 주세요.',2]
 ];
 const variants=[
 {labels:['환불 요청','배송 문의','계정 문제'],template:'이 문장은 {}에 관한 내용입니다.'},
 {labels:['환불 요청','배송 문의','계정 문제'],template:'This text is about {}.'},
 {labels:['환불을 요청하거나 결제를 취소하고 돈을 돌려받는 것','택배 배송 상태, 도착 날짜 또는 운송장 번호를 확인하는 것','로그인, 비밀번호, 회원 가입 또는 계정 접근 문제를 해결하는 것'],template:'고객이 원하는 것은 {}입니다.'},
 ];
 const all=[];
 for(const v of variants){const outputs=[];for(const [text,expected]of samples){const start=performance.now();const r=await model(text,v.labels,{hypothesis_template:v.template});outputs.push({text,expected,predicted:v.labels.indexOf(r.labels[0]),score:r.scores[0],margin:r.scores[0]-r.scores[1],ms:Math.round(performance.now()-start)});}all.push({...v,correct:outputs.filter(o=>o.expected===o.predicted).length,total:samples.length,outputs});}
 return all;
})()
