#!/data/data/com.termux/files/usr/bin/sh
cd "$(dirname "$0")" || exit 1
exec python -m http.server 8765 --bind 127.0.0.1
