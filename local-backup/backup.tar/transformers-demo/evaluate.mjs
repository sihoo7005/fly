import { readFile } from 'node:fs/promises';
const tabs=await(await fetch('http://127.0.0.1:9223/json/list')).json();
const ws=new WebSocket(tabs.find(t=>t.type==='page').webSocketDebuggerUrl);
await new Promise((r,j)=>{ws.onopen=r;ws.onerror=j;});
let id=0; const pending=new Map();
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id){const p=pending.get(m.id);if(p){pending.delete(m.id);m.error?p.reject(m.error):p.resolve(m.result);}}};
function send(method,params={}){return new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});}
const timer=setTimeout(()=>{console.error('Evaluation timeout');process.exit(1);},180000);
try{
 await send('Page.navigate',{url:'http://127.0.0.1:8765/'});
 const expression=await readFile(process.argv[2],'utf8');
 const result=await send('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});
 if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));
 console.log(JSON.stringify(result.result.value,null,2));
}finally{clearTimeout(timer);ws.close();}
