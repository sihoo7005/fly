import assert from 'node:assert/strict';
import { setTimeout as delay } from 'node:timers/promises';
import { writeFile } from 'node:fs/promises';
const base = 'http://127.0.0.1:8766';
let ready = false;
for (let i = 0; i < 180; i++) {
  try { ready = (await (await fetch(`${base}/health`)).json()).ready; } catch {}
  if (ready) break;
  await delay(500);
}
assert.ok(ready, 'API must finish loading');
async function post(body, type='application/json') {
  return fetch(`${base}/classify`, { method:'POST', headers:{'Content-Type':type}, body:typeof body==='string'?body:JSON.stringify(body) });
}
assert.equal((await post('{')).status,400);
assert.equal((await post({text:'x'.repeat(17000),labels:['a','b']})).status,413);
assert.equal((await post({text:'hello',labels:['only one']})).status,400);
assert.equal((await post({text:'hello',labels:['same','same']})).status,400);
assert.equal((await post({text:'hello',labels:['yes','no']},'text/plain')).status,415);
assert.equal((await fetch(`${base}/missing`)).status,404);
const input = {text:'the product is not working. please refund it.',labels:['refund request','delivery ask','account problems']};
const first = post(input);
let busy=false;
for(let i=0;i<100;i++) {
  busy=(await(await fetch(`${base}/health`)).json()).busy;
  if(busy)break;
  await delay(10);
}
assert.ok(busy,'Request must mark the model busy');
assert.equal((await post(input)).status,429);
const response=await first;
assert.equal(response.status,200);
const result=await response.json();
assert.equal(result.labels[0],'refund request');
assert.ok(Math.abs(result.scores.reduce((a,b)=>a+b,0)-1)<0.001);
const second=await post({text:'비밀번호를 잊어버려서 로그인이 안 됩니다.',labels:['환불 요청','배송 문의','계정 문제']});
assert.equal(second.status,200);
assert.equal((await second.json()).labels[0],'계정 문제');
await writeFile(new URL('./api-results.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
console.log('PASS: English/Korean inference, invalid JSON, labels, content type, route and busy response');
