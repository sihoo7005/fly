import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
const tabs = await (await fetch('http://127.0.0.1:9223/json/list')).json();
const ws = new WebSocket(tabs[0].webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{ ws.onopen=resolve; ws.onerror=reject; });
let id=0;
const pending=new Map();
const requests=[];
ws.onmessage=event=>{
  const message=JSON.parse(event.data);
  if(message.id) { const p=pending.get(message.id); if(p) {pending.delete(message.id);message.error?p.reject(message.error):p.resolve(message.result);} }
  if(message.method==='Network.requestWillBeSent') requests.push(message.params.request.url);
};
function send(method,params={}) {return new Promise((resolve,reject)=>{const n=++id;pending.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));});}
const timeout=setTimeout(()=>{console.error('Test timeout');process.exit(1);},180000);
try {
  await send('Runtime.enable');
  await send('Network.enable');
  await send('Network.setBlockedURLs',{urls:['*huggingface.co*','*cdn.jsdelivr.net*']});
  await send('Page.navigate',{url:'http://127.0.0.1:8765/'});
  const run=await send('Runtime.evaluate',{expression:`(async()=>{
    while(!window.classify) await new Promise(r=>setTimeout(r,100));
    const labels=['환불 요청','배송 문의','계정 문제'];
    const samples=['상품이 고장 났어요. 환불해 주세요.','택배가 아직 도착하지 않았어요. 언제 배송되나요?','비밀번호를 잊어버려서 로그인이 안 됩니다.'];
    const outputs=[];
    for(const text of samples) outputs.push(await window.classify(text,labels));
    outputs.push(await window.classify('the product is not working. please refund it.', ['refund request','delivery ask','account problems']));
    document.querySelector('#run').click();
    while(document.querySelector('#run').disabled) await new Promise(r=>setTimeout(r,100));
    return {outputs,status:document.querySelector('#status').textContent,result:document.querySelector('#result').textContent};
  })()`,awaitPromise:true,returnByValue:true});
  if(run.exceptionDetails) throw Error(JSON.stringify(run.exceptionDetails));
  const data=run.result.value;
  const expected=['환불 요청','배송 문의','계정 문제','refund request'];
  data.outputs.forEach((o,i)=>{assert.equal(o.labels[0],expected[i]);assert.ok(Math.abs(o.scores.reduce((a,b)=>a+b,0)-1)<0.001);});
  assert.ok(data.status.startsWith('완료'));
  assert.ok(requests.every(url=>url.startsWith('http://127.0.0.1:8765/')||url.startsWith('data:')||url.startsWith('blob:')));
  await writeFile(new URL('./results.json',import.meta.url),JSON.stringify({...data,requests},null,2));
  console.log(JSON.stringify(data,null,2));
} finally {clearTimeout(timeout);ws.close();}
