import { createServer } from 'node:http';
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('.', import.meta.url));
const children = [];
let socket, ready = false, busy = false, id = 0;
const pending = new Map();
function cleanup() {
  socket?.close();
  for (const child of children) child.kill('SIGTERM');
}
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => { cleanup(); process.exit(); });
function launch(command, args, env = process.env) {
  const child = spawn(command, args, { env, stdio: 'ignore' });
  children.push(child);
  child.on('error', error => { console.error(error.message); cleanup(); process.exit(1); });
  child.on('exit', () => { if (ready) { console.error('Inference process stopped'); cleanup(); process.exit(1); } });
}
function send(method, params = {}) {
  return new Promise((resolve, reject) => {
    const number = ++id;
    const timer = setTimeout(() => { pending.delete(number); reject(Error('Inference timed out')); }, 60000);
    pending.set(number, { resolve, reject, timer });
    socket.send(JSON.stringify({ id: number, method, params }));
  });
}
async function evaluate(expression) {
  const result = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
  if (result.exceptionDetails) throw Error(result.exceptionDetails.text);
  return result.result.value;
}
function reply(res, code, body) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}
const server = createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return reply(res, ready ? 200 : 503, { ready, busy });
  if (req.method !== 'POST' || req.url !== '/classify') return reply(res, 404, { error: 'Use POST /classify or GET /health' });
  if (!ready) return reply(res, 503, { error: 'Model is loading' });
  if (!(req.headers['content-type'] || '').startsWith('application/json')) return reply(res, 415, { error: 'Content-Type must be application/json' });
  let text, labels;
  try {
    const chunks = []; let bytes = 0;
    for await (const chunk of req) {
      bytes += chunk.length;
      if (bytes > 16384) return reply(res, 413, { error: 'Request body exceeds 16 KB' });
      chunks.push(chunk);
    }
    ({ text, labels } = JSON.parse(Buffer.concat(chunks).toString('utf8')));
    if (typeof text !== 'string' || !text.trim() || text.length > 2000 || !Array.isArray(labels) || labels.length < 2 || labels.length > 10 || labels.some(x => typeof x !== 'string' || !x.trim() || x.length > 200) || new Set(labels).size !== labels.length) {
      return reply(res, 400, { error: 'text: 1–2000 characters; labels: 2–10 unique non-empty strings, at most 200 characters each' });
    }
  } catch { return reply(res, 400, { error: 'Invalid JSON' }); }
  // One WASM model handles one request at a time; callers retry a 429 response.
  if (busy) return reply(res, 429, { error: 'Model is busy; retry shortly' });
  busy = true;
  try {
    const result = await evaluate(`window.classify(${JSON.stringify(text)}, ${JSON.stringify(labels)})`);
    reply(res, 200, result);
  } catch (error) { reply(res, 500, { error: error.message }); }
  finally { busy = false; }
});
server.requestTimeout = 10000;
server.on('error', error => { console.error(error.message); cleanup(); process.exit(1); });
await new Promise(resolve => server.listen(8766, '127.0.0.1', resolve));
console.log('Loading model… API: http://127.0.0.1:8766');
launch('python', ['-m', 'http.server', '8767', '--bind', '127.0.0.1', '--directory', root]);
launch('chromium-browser', ['--headless', '--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking', `--user-data-dir=${join(root, '.chromium-api')}`, '--remote-debugging-port=9224', 'about:blank'], { ...process.env, LD_LIBRARY_PATH: '/data/data/com.termux/files/usr/lib' });
try {
  let tab;
  for (let attempt = 0; attempt < 100; attempt++) {
    try { const tabs = await (await fetch('http://127.0.0.1:9224/json/list')).json(); tab = tabs.find(x => x.type === 'page'); if (tab) break; } catch {}
    await delay(200);
  }
  if (!tab) throw Error('Chromium did not start');
  socket = new WebSocket(tab.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
  socket.onmessage = event => {
    const message = JSON.parse(event.data), item = pending.get(message.id);
    if (!item) return;
    clearTimeout(item.timer); pending.delete(message.id);
    message.error ? item.reject(Error(message.error.message)) : item.resolve(message.result);
  };
  socket.onclose = () => { ready = false; for (const p of pending.values()) { clearTimeout(p.timer); p.reject(Error('Inference connection closed')); } pending.clear(); };
  await send('Network.enable');
  await send('Network.setBlockedURLs', { urls: ['*huggingface.co*', '*cdn.jsdelivr.net*'] });
  await send('Page.navigate', { url: 'http://127.0.0.1:8767/' });
  await evaluate(`(async () => {
    while (!window.classify) await new Promise(r => setTimeout(r, 100));
    return window.classify('please refund it', ['refund request', 'delivery ask']);
  })()`);
  ready = true;
  console.log('Ready: POST http://127.0.0.1:8766/classify');
} catch (error) { console.error(error.message); cleanup(); process.exit(1); }
