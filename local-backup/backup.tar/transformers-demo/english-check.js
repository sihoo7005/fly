(async()=>{
 const {pipeline,env}=await import('./vendor/transformers.min.js');
 env.allowRemoteModels=false;env.allowLocalModels=true;env.localModelPath='./models/';
 env.backends.onnx.wasm.wasmPaths=new URL('./vendor/',location.href).href;env.backends.onnx.wasm.numThreads=1;
 const model=await pipeline('zero-shot-classification','multilingual-MiniLMv2-L6-mnli-xnli',{dtype:'q8',device:'wasm'});
 const text='the product is not working. please refund it.';
 const labels=['refund request','delivery ask','account problems'];
 const outputs=[];
 for(const hypothesis_template of ['이 문장은 {}에 관한 내용입니다.','This text is about {}.','The customer is asking for {}.']){
 const start=performance.now();outputs.push({hypothesis_template,...await model(text,labels,{hypothesis_template}),ms:Math.round(performance.now()-start)});
 }
 return outputs;
})()
